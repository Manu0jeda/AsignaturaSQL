
public class Entrada {
    
    public static void main(String[] args) {
        int puerto = 8081;
        SimpleWebServer SServer=  new SimpleWebServer(puerto);
        System.out.println("constructor");
        SServer.arrancar();
    }
}