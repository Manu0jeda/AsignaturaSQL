
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class SimpleWebServer {

    String url = "jdbc:mysql://localhost:3306/ventas"; // URL de conexión
    String usuario = "admin"; //  usuario de MySQL
    String contraseña = "ceste"; //  contraseña de MySQL
    String query="";

    int puerto=0; 
    static DB db=null;

    SimpleWebServer(int puerto) {
        this.puerto = puerto; // Puerto en el que el servidor escuchará
    }
     
    void arrancar(){
        try{
            ServerSocket serverSocket = new ServerSocket(puerto);
            System.out.println("Servidor web escuchando en el puerto " + puerto);
         
            db= new DB("jdbc:mysql://localhost:3306/ventas",usuario,contraseña);
            db.conectar();
            while (true) {
                Socket clientSocket = serverSocket.accept();
                analizarRequest(clientSocket);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private static void analizarRequest(Socket clientSocket) throws IOException {
     int opcion=0;
     int res=0;
     String query="";
     String html="";
      try{
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        String cabeceraHTTP = in.readLine();
        if (cabeceraHTTP != null) {
            String[] requestParts = cabeceraHTTP.split(" ");
            if (requestParts.length == 3 && requestParts[0].equals("GET")) {
                String ficheroHTMLpedido = requestParts[1];
                Map<String, String> params = obtenerParametros(ficheroHTMLpedido);
                

                String[] orden = ficheroHTMLpedido.split("/");
                if (ficheroHTMLpedido == null || ficheroHTMLpedido.equals("") || ficheroHTMLpedido.equals("/")) {
                    servirFicheroHTML("/index.html", out);
                    
                }else if (ficheroHTMLpedido.startsWith("/accionDQL")) {
                   if (params.isEmpty()) {
                        sinParámetros( out);
                       
                   } else {                   
                      String op=params.get("opcion"); 
                      opcion=0;
                      try {
                          opcion = Integer.parseInt(op);        
                      } catch (NumberFormatException e) {
                          opcion=0;
                      }
                      if (opcion<100){
                        lanzarDQL_responderHTM(opcion,out);
                      }else{
                        responderHTM_Formulario(opcion,out);
                      }
                      
                  }
                   
                }else if (ficheroHTMLpedido.startsWith("/accionDML101")) {
                    if (params.isEmpty()) {
                        sinParámetros( out);
                   } else {
                    
                    String nom=params.get("nombre_categoria"); 
                    String des=params.get("descripcion"); 
                    query="INSERT INTO categorias ( NombreCategoria, Descripcion) VALUES ( '"+nom+"', '"+des+"')";
                    System.out.println(query);

                    res=db.ejecutarUpdate(query);
                    html=abrirHTML("Categoría insertada")+
                        "<p> <a href='/menuSelect.html'> Volver al menú</a>"+
                        cerrarHTML();
                    out.println(html);
                    }
                    } else if (ficheroHTMLpedido.startsWith("/accionDML102")) {
                      if (params.isEmpty()) {
                        sinParámetros(out);
                    } else {
                        String nombreCompania = params.get("nombre_compania");
                        String nombreContacto = params.get("nombre_contacto");
                        String cargoContacto = params.get("cargo_contacto");
                        String direccion = params.get("direccion");
                        String ciudad = params.get("ciudad");
                        String region = params.get("region");
                        String codPostal = params.get("cod_postal");
                        String pais = params.get("pais");
                        String telefono = params.get("telefono");
                        String fax = params.get("fax");
                        String paginaPrincipal = params.get("pagina_principal");

                        query = "INSERT INTO proveedores (NombreCompania, NombreContacto, CargoContacto, Direccion, Ciudad, Region, CodPostal, Pais, Telefono, Fax, PaginaPrincipal) VALUES ('"
                              + nombreCompania + "', '" + nombreContacto + "', '" + cargoContacto + "', '" + direccion + "', '" 
                                + ciudad + "', '" + region + "', '" + codPostal + "', '" + pais + "', '" + telefono + "', '" 
                                + fax + "', '" + paginaPrincipal + "')";
                        System.out.println(query);

                        res = db.ejecutarUpdate(query);
                        html = abrirHTML("Proveedor insertado") +
                                "<p> <a href='/menuSelect.html'> Volver al menú</a>" +
                                cerrarHTML();
                        out.println(html);
                    }
                } else {
                    // Sirve páginas web estáticas desde un directorio "public"
                    servirFicheroHTML(ficheroHTMLpedido, out);
                }
           
            } else {
                // Respuesta de error si la solicitud no es GET
                out.println("HTTP/1.1 405 Method Not Allowed");
            }
        }
        clientSocket.close();
      }catch(Exception e){
        e.printStackTrace();
      }
    }

    private static void servirFicheroHTML(String requestedFile, PrintWriter out) throws IOException {
        String filePath = "C:/Java_proyectos/raizWeb" + requestedFile; // El directorio "public" contiene los archivos estáticos
        File file = new File(filePath);
        
        if (file.exists() && file.isFile()) {
            BufferedReader fileIn = new BufferedReader(new FileReader(file));
            out.println("HTTP/1.1 200 OK");
            out.println("Content-Type: text/html"); // Asume que todos los archivos estáticos son HTML
            out.println();
            String line;
            while ((line = fileIn.readLine()) != null) {
                out.println(line);
            }
            fileIn.close();
        } else {
            // Error 404 si el archivo no se encuentra
            out.println("HTTP/1.1 404 Not Found");
        }
    }

    private static Map<String, String> obtenerParametros(String requestedFile) {
        Map<String, String> params = new HashMap<>();
        int paramsIndex = requestedFile.indexOf("?");
        if (paramsIndex > 0) {
            String paramsString = requestedFile.substring(paramsIndex + 1);
            String[] paramPairs = paramsString.split("&");
            for (String pair : paramPairs) {
                String[] keyValue = pair.split("=");
                if (keyValue.length == 2) {
                    try {
                        String key = URLDecoder.decode(keyValue[0], "UTF-8");
                        String value = URLDecoder.decode(keyValue[1], "UTF-8");
                        params.put(key, value);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return params;
    }
    static void sinParámetros(PrintWriter out){
        out.println(abrirHTML("No se han recibido parámetros")+cerrarHTML()); 
    }

    static String abrirHTML(String titulo){
        String htm="HTTP/1.1 200 OK \n Content-Type: text/html"+
        "\n \n"+ 
        "\n <html lang='es'><head><meta charset='UTF-8'></head><body>"+
        "<h1> "+titulo+"</h1>";
        return htm;
    }   
    
    static String cerrarHTML(){ 
        return  "\n </body></html>";
    }

    static void lanzarDQL_responderHTM(int opcion, PrintWriter out){
        List <String> cabeceras = null;
        String htmlTabla="";
        String query="";
        String titulo="";
        switch (opcion) {
            case 1:
                query="SELECT NombreCompania, NombreContacto, Telefono FROM proveedores;";
                titulo="Nombre de la compañía, nombre del contacto y teléfono de todos los proveedores";
                break;
            case 2:
                query="SELECT NombreProducto FROM productos WHERE productos.Id_Producto "
                    + "NOT IN (SELECT DISTINCT detallespedidos.IdProducto FROM detallespedidos);";
                titulo="Nombre de productos no utilizados en ningún pedido";
                break;
            case 3:
                query="SELECT DISTINCT NombreContacto FROM clientes WHERE clientes.Id_Cliente IN (SELECT pedidos.Id_Cliente "
                    + "FROM pedidos WHERE pedidos.PaisDestinatario = clientes.Pais) ORDER BY NombreContacto  ASC;";
                titulo="Listado de clientes que han realizado pedidos al mismo país en el que se encuentran";
                break;    
            case 4:
                query="SELECT pedidos.Id_Empleado, SUM(detallespedidos.Cantidad * detallespedidos.PrecioUnidad * (1 - detallespedidos.Descuento)) AS Cuantia "
                    + "FROM pedidos JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido GROUP BY pedidos.Id_Pedido, pedidos.Id_Empleado "
                    + "ORDER BY pedidos.Id_Empleado;";
                titulo="Listado con la cuantia de cada pedido junto con el id del empleado que la ha realizado, ordenado por Id_Empleado";
                break;  
            case 5:
              query="SELECT NombreProducto, Id_Producto, UnidadesEnExistencia FROM productos WHERE UnidadesEnExistencia BETWEEN 53 AND 120;";
              titulo="Nombre del producto e Id de aquellos productos que hay en existencia una cantidad entre 53 y 120 (ambas inclusive)";
              break;  
            case 6:
              query="SELECT NombreContacto, NombreCompania, Direccion, Ciudad, Pais, CodPostal FROM clientes "
                  + "WHERE (Pais ='Espana' AND CodPostal = '28023') OR (Pais ='Mexico' AND CodPostal = '5033');";
              titulo="Nombre, la compañía, la dirección, la ciudad y el pais de mis clientes que son de España y estén ubicadas "
                  + "en el código postal 28023 y las que son de México y su código sea el 05033";
              break;  
            case 7:
              query="SELECT NombreContacto, NombreCompania, Pais, Ciudad, Telefono FROM clientes "
                  + "WHERE Pais = 'Francia' OR Pais = 'Reino Unido' ORDER BY Pais;";
              titulo="Nombre del contacto, la compañía, el país, la ciudad y el teléfono de mis clientes franceses o ingleses.";
              break;  
            case 8:
              query="SELECT NombreContacto, Ciudad FROM clientes WHERE Pais = 'Espana';";
              titulo="Nombre y la ciudad de mis clientes que son españoles";
              break;  
            case 9:
              query="SELECT categorias.NombreCategoria, productos.NombreProducto FROM productos RIGHT JOIN categorias ON productos.Id_Categoria = categorias.Id_Categoria "
                  + "ORDER BY categorias.NombreCategoria;";
              titulo="Listado de categorías y los productos asociados si existen";
              break;  
            case 10:
              query="SELECT NombreProducto, Id_categoria, PrecioUnidad FROM productos WHERE PrecioUnidad > (SELECT AVG(PrecioUnidad) FROM productos "
                  + "WHERE id_categoria IN (SELECT id_categoria FROM categorias WHERE NombreCategoria = 'Lácteos'));";
              titulo="Nombres de los productos y su categoría y precio/ unidad que tienen un precio más alto que el precio promedio de los productos "
                  + "de la categoría 'Lácteos';";
              break;  
            case 101:
                query="SELECT NombreCompania, ciudad  FROM clientes WHERE Pais='Espana'";
                titulo="Nombres de los productos y su categoría y precio/ unidad que tienen un precio más alto que el precio promedio de "
                    + "los productos de la categoría 'Lácteos'";
                break;    
            default:
                System.out.println("Opción no válida.");             
        }
        
        htmlTabla= db.ejecutarQuery(query, cabeceras);        
        out.println(abrirHTML(titulo)+htmlTabla+cerrarHTML());
    }

    static void responderHTM_Formulario(int opcion, PrintWriter out){   
        String html="";
        switch (opcion) {
            case 101:
                html=abrirHTML("Agregar Nueva Categoría")+
                    "<form action='accionDML101' method='GET'>\n"+
                    "<label for='id_categoria'>ID Categoría:(Generado automáticamente)</label><br>\n"+
                    "<input type='number' id='id_categoria' name='id_categoria' value='automático' disabled><br><br>\n"+
                    "<label for='nombre_categoria'>Nombre Categoría:</label><br>\n"+
                    "<input type='text' id='nombre_categoria' name='nombre_categoria' required><br><br>\n"+
                    "<label for='descripcion'>Descripción:</label><br>\n"+
                    "<textarea id='descripcion' name='descripcion' rows='4' cols='50' required></textarea><br><br>\n"+
                    "<input type='submit' value='Guardar Categoría'>\n"+
                    "</form>\n"+ cerrarHTML();
                out.println(html);
                break;    
            case 102:
              html = abrirHTML("Agregar Nuevo Proveedor") +
                  "<form action='accionDML102' method='GET'>\n" +
                  "<label for='id_proveedor'>ID Proveedor:(Generado automáticamente)</label><br>\n" +
                  "<input type='number' id='id_proveedor' name='id_proveedor' value='automático' disabled><br><br>\n" +
                  "<label for='nombre_compania'>Nombre Compañía:</label><br>\n" +
                  "<input type='text' id='nombre_compania' name='nombre_compania' required><br><br>\n" +
                  "<label for='nombre_contacto'>Nombre Contacto:</label><br>\n" +
                  "<input type='text' id='nombre_contacto' name='nombre_contacto' required><br><br>\n" +
                  "<label for='cargo_contacto'>Cargo Contacto:</label><br>\n" +
                  "<input type='text' id='cargo_contacto' name='cargo_contacto' required><br><br>\n" +
                  "<label for='direccion'>Dirección:</label><br>\n" +
                  "<input type='text' id='direccion' name='direccion' required><br><br>\n" +
                  "<label for='ciudad'>Ciudad:</label><br>\n" +
                  "<input type='text' id='ciudad' name='ciudad' required><br><br>\n" +
                  "<label for='region'>Región:</label><br>\n" +
                  "<input type='text' id='region' name='region'><br><br>\n" +
                  "<label for='cod_postal'>Código Postal:</label><br>\n" +
                  "<input type='text' id='cod_postal' name='cod_postal'><br><br>\n" +
                  "<label for='pais'>País:</label><br>\n" +
                  "<input type='text' id='pais' name='pais' required><br><br>\n" +
                  "<label for='telefono'>Teléfono:</label><br>\n" +
                  "<input type='tel' id='telefono' name='telefono'><br><br>\n" +
                  "<label for='fax'>Fax:</label><br>\n" +
                  "<input type='tel' id='fax' name='fax'><br><br>\n" +
                  "<label for='pagina_principal'>Página Principal:</label><br>\n" +
                  "<input type='url' id='pagina_principal' name='pagina_principal'><br><br>\n" +
                  "<input type='submit' value='Guardar Proveedor'>\n" +
                  "</form>\n" + cerrarHTML();
              out.println(html);
              break;

            default:
                System.out.println("Opción no válida.");             
        }
        
       // htmlTabla= db.ejecutarQuery(query, cabeceras);        
       // out.println(abrirHTML(titulo)+htmlTabla+cerrarHTML());
    }
  
}