import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


class GestionUsuarios {
    String url = null; // URL de conexión
    String usuario = null; //  usuario de MySQL
    String password = null; //  contraseña de MySQL

    Connection conexion=null;
    Statement sentencia=null;
    ResultSet resultado=null;


    GestionUsuarios(String url, String usuario, String password){
        this.url=url;
        this.usuario=usuario;
        this.password=password;
        sentencia=conectar();
        if (sentencia==null)
            return;
        else
            usuariosInfo();
    }
    Statement conectar(){
        Statement sentencia=null;
        try {
            //1.- Cargar el driver JDBC para MySQL que está en mysql-connector-j-9.1.0.jar
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2.- Establecer la conexión
            // Conecta al servidor MySQL. La URL no incluye el nombre de una base de datos específica, 
            // ya que queremos listar todas las bases de datos.
            conexion = DriverManager.getConnection(url,usuario,password);

            //3.- Crea un objeto Statement para ejecutar consultas SQL
            sentencia = conexion.createStatement();
            return sentencia;
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se pudo cargar el controlador JDBC: " + e.getMessage());
            return null;
        }catch(SQLException e ){
            System.err.println("Otro error JDBC: " + e.getMessage());
            return null;
        }
    }

    void usuariosInfo() {
        try{
            System.out.println("\n Gestión de usuarios:");

          // Lista de usuarios
            System.out.println("\n Lista de usuarios registrados:");
            resultado = sentencia.executeQuery("SELECT user, host FROM mysql.user;");
            while (resultado.next()) {
                System.out.println("Usuario: "+resultado.getString(1)+ "\t Acceso desde Host: "+resultado.getString(2));
            }

             // Privilegios
             String usua="'root'@'%'"; // % significa desde cualquier sitio, habria que poner root con esos permisos
             resultado = sentencia.executeQuery("SHOW GRANTS FOR "+ usua+ ";");
              // Mostrar los resultados
            if (resultado.next()) {
                String info = resultado.getString(1);
                System.out.println("\n Privilegios del usuario "+ usua+": \n" + info);
            }
            

            // Cerrar la conexión y los recursos
            resultado.close();
            sentencia.close();
            conexion.close();

        } catch ( SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
