import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


class Info {
    String url = null; // URL de conexión
    String usuario = null; //  usuario de MySQL
    String password = null; //  contraseña de MySQL

    Connection conexion=null;
    Statement sentencia=null;
    ResultSet resultado=null;


    Info(String url, String usuario, String password){
        this.url=url;
        this.usuario=usuario;
        this.password=password;
        sentencia=conectar();
        if (sentencia==null)
            return;
        else
            infoDB();
    }
    Statement conectar(){
        Statement sentencia=null;
        try {
            //1.- Cargar el driver JDBC para MySQL que está en mysql-connector-j-9.1.0.jar
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2.- Establecer la conexión
            // Conecta al servidor MySQL. La URL no incluye el nombre de una base de datos específica, 
            // ya que queremos listar todas las bases de datos.
            conexion = DriverManager.getConnection(url,usuario,password);

            //3.- Crea un objeto Statement para ejecutar consultas SQL
            sentencia = conexion.createStatement();
            return sentencia;
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se pudo cargar el controlador JDBC: " + e.getMessage());
            return null;
        }catch(SQLException e ){
            System.err.println("Otro error JDBC: " + e.getMessage());
            return null;
        }
    }

    
    void infoDB() {
        try{
            System.out.println("\n Información en el servidor MySQL:");
 
            // Versión 
            resultado = sentencia.executeQuery("SELECT VERSION()");
            // Mostrar los resultados1
             if (resultado.next()) {
                String version = resultado.getString(1);
                System.out.println("Versión del servidor MySQL: " + version);
            }

             // Tiempo de actividad del servidor
             resultado = sentencia.executeQuery("SHOW STATUS LIKE 'Uptime'");
             // Mostrar los resultados1
             int uptime=0;
             if (resultado.next()) {
                 uptime = resultado.getInt(2);
                 System.out.println("Tiempo de actividad del servidor en segundos: " + uptime + " segundos");
             }
           
           //conexiones simultáneas
             resultado = sentencia.executeQuery("SHOW STATUS LIKE 'Max_used_connections'");
             // Mostrar los resultados
             if (resultado.next()) {
                 String actualiza = resultado.getString(2);
                 System.out.println("Número máximo de conexiones simultáneas desde que se inició el servidor: " + actualiza+ " conexiones");
             }

           //directorio de MySQL
           resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'basedir'");
           // Mostrar los resultados
           if (resultado.next()) {
               String dir = resultado.getString(2);
               System.out.println("Directorio donde se instaló MySQL: " + dir);
           }

           //versión MySQL
           resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'version'");
           // Mostrar los resultados
           if (resultado.next()) {
               String info = resultado.getString(2);
               System.out.println("Versión de MySQL: " + info);
           }

            //Denominación del MySQL
            resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'version_comment'");
            // Mostrar los resultados
            if (resultado.next()) {
                String info = resultado.getString(2);
                System.out.println("Versión de MySQL: " + info);
            }

            

              //S.O
              resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'version_compile_os'");
              // Mostrar los resultados
              if (resultado.next()) {
                  String info = resultado.getString(2);
                  System.out.println("Sistema operativo: " + info);
              }

            //hardware
            resultado = sentencia.executeQuery("SHOW VARIABLES LIKE 'version_compile_machine'");
            // Mostrar los resultados
            if (resultado.next()) {
                String info = resultado.getString(2);
                System.out.println("Arquitectura hardware: " + info);
            }


            //Clave pública
             resultado = sentencia.executeQuery("SHOW STATUS LIKE 'Caching_sha2_password_rsa_public_key'");
             if (resultado.next()) {
                 String pem = resultado.getString(2);
                 System.out.println("Clave pública RSA en formato PEM (Privacy-Enhanced Mail), que el servidor utiliza para la autenticación: \n" + pem);
             }
             


            // Cerrar la conexión y los recursos
            resultado.close();
            sentencia.close();
            conexion.close();

        } catch ( SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    


}
