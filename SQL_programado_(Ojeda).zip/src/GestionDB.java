import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


class GestionDB {
    String url = null; // URL de conexión
    String usuario = null; //  usuario de MySQL
    String password = null; //  contraseña de MySQL

    Connection conexion=null;
    Statement sentencia=null;
    ResultSet resultado=null;


    GestionDB(String url, String usuario, String password){
        this.url=url;
        this.usuario=usuario;
        this.password=password;
        sentencia=conectar();
        if (sentencia==null)
            return;
        else
            listarDBs();
    }
    Statement conectar(){
        Statement sentencia=null;
        try {
            //1.- Cargar el driver JDBC para MySQL que está en mysql-connector-j-9.1.0.jar
            Class.forName("com.mysql.cj.jdbc.Driver");

            //2.- Establecer la conexión
            // Conecta al servidor MySQL. La URL no incluye el nombre de una base de datos específica, 
            // ya que queremos listar todas las bases de datos.
            conexion = DriverManager.getConnection(url,usuario,password);

            //3.- Crea un objeto Statement para ejecutar consultas SQL
            sentencia = conexion.createStatement();
            return sentencia;
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se pudo cargar el controlador JDBC: " + e.getMessage());
            return null;
        }catch(SQLException e ){
            System.err.println("Otro error JDBC: " + e.getMessage());
            return null;
        }
    }

    
    void listarDBs() {
        try{
 
            // Ejecutar la consulta para obtener las bases de datos
            resultado = sentencia.executeQuery("SHOW DATABASES");
            System.out.println("\n Bases de datos disponibles:");
            while (resultado.next()) {
                System.out.println(resultado.getString(1));
            }

            System.out.println("Elija una acción: \n");
            Scanner scanner2 = new Scanner(System.in);
            int opcion=0;

            do {
                mostrarMenu(); // Mostramos el menú
                System.out.print("Elige una opción: ");
                try{opcion = scanner2.nextInt();}catch(Exception e){opcion=0;}
                Scanner scanner3 = new Scanner(System.in);
                String nombreDB;
                switch (opcion) {

                    case 1:
                        // crear una DB nueva
                        System.out.println("Inserte el nombre de la Base de Datos: ");
                        nombreDB = scanner3.nextLine();
                        scanner3.close();
                        System.out.println("\n Crear una Base de Datos nueva llamada: "+ nombreDB);
                        sentencia.executeUpdate("DROP DATABASE IF EXISTS " + nombreDB);
                        sentencia.executeUpdate("CREATE DATABASE " + nombreDB);
                        sentencia.executeUpdate("USE " + nombreDB);
                        System.out.println("\n Base de datos: "+ nombreDB+" creada");
                        pulsa_tecla();
                        break;
                    case 2:
                        // Crear una tabla
                        System.out.println("Inserte el nombre de la Base de Datos que quiere usar: ");
                        nombreDB = scanner3.nextLine();
                        sentencia.executeUpdate("USE " + nombreDB);
                        System.out.println("Inserte el nombre de la tabla: ");
                        String tabla = scanner3.nextLine();
                        scanner3.close();
                        System.out.println("\n Crear una la tabla: "+ tabla);
                        String sql = "CREATE TABLE IF NOT EXISTS " + tabla + " (" +
                                     "id INT AUTO_INCREMENT PRIMARY KEY, " +
                                     "nombre VARCHAR(50) NOT NULL, " +
                                     "email VARCHAR(100) NOT NULL UNIQUE, " +
                                     "fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                                     ")";
                        sentencia.executeUpdate(sql);
                        System.out.println("\n Tabla: "+ tabla+" creada");
                        pulsa_tecla();
                        break;
                    case 3:
                        //Isertar datos
                        System.out.println("¿En que tabla desea insertar datos?");
                        String tabla1 = scanner3.nextLine();
                        scanner3.close();
                        System.out.println("\n Insertar filas  en la tabla " + tabla1);
                        String[] inserts = {
                            "INSERT INTO usuarios (nombre, email) VALUES ('Juan Plot', 'juan.plot@example.com')",
                            "INSERT INTO usuarios (nombre, email) VALUES ('María Garty', 'maria.garty@example.com')",
                            "INSERT INTO usuarios (nombre, email) VALUES ('Carlos Loem', 'carlos.loem@example.com')",
                            "INSERT INTO usuarios (nombre, email) VALUES ('Ana Manty', 'ana.manty@example.com')",
                            "INSERT INTO usuarios (nombre, email) VALUES ('Luisa Fern', 'luisa.fern@example.com')"
                        };
                        int n=0;
                        for (String sql2 : inserts) {
                            sentencia.executeUpdate(sql2);
                            n++;
                        }

                      System.out.println(n + " filas insertadas exitosamente en la tabla " + tabla1);
                        pulsa_tecla();
                        break;
                    case 0:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        pulsa_tecla();
                }
            } while (opcion != 0); // Repetimos hasta que el usuario elija la opción 0
            scanner2.close(); // Cerramos el scanner
            
            // Cerrar la conexión y los recursos
            resultado.close();
            sentencia.close();
            conexion.close();

        } catch ( SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    private static void mostrarMenu() {
      System.out.println("\n--- Menú ---");
      System.out.println("1. Crear nueva Base de Datos");
      System.out.println("2. Crear una tabla");
      System.out.println("3. Insertar Datos");
      System.out.println("0. Salir");
  }
  public static void pulsa_tecla(){
      System.out.println("Pulsa ENTER para continuar...");
      try{System.in.read(); // Espera a que el usuario presione una tecla
      }catch(Exception e){}
  }
}
