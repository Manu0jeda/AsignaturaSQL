import java.util.Scanner;

public class Entrada {

  public static void main(String[] args) {
    String url = "jdbc:mysql://localhost:3306/"; // URL de conexión
    String usuario = "root"; // usuario de MySQL
    String contraseña = "Password"; // contraseña de MySQL

    Scanner scanner = new Scanner(System.in);
    int opcion = 0;
    mostrarMenu(); // Mostramos el menú
    System.out.print("Elige una opción: ");
    do {
      try {
        opcion = scanner.nextInt();
      } catch (Exception e) {
        opcion = 0;
      }

      switch (opcion) {

        case 1:
          new Info(url, usuario, contraseña);
          pulsa_tecla();
          break;
        case 2:
          new Estados(url, usuario, contraseña);
          pulsa_tecla();
          break;
        case 3:
          new ConfiguracionVariables(url, usuario, contraseña);
          pulsa_tecla();
          break;
        case 4:
          new GestionUsuarios(url, usuario, contraseña);
          pulsa_tecla();
          break;
        case 5:
          new GestionDB(url, usuario, contraseña);
          pulsa_tecla();
          break;
        case 6:
          new Consultas(url, usuario, contraseña);
          pulsa_tecla();
          break;
        case 0:
          System.out.println("Saliendo del programa...");
          break;
        default:
          System.out.println("Opción no válida.");
          pulsa_tecla();
      }
    } while (opcion != 0); // Repetimos hasta que el usuario elija la opción 0

    scanner.close(); // Cerramos el scanner
  }


  private static void mostrarMenu() {
    System.out.println("\n--- Menú ---");
    System.out.println("1. Información del servidor MySQL");
    System.out.println("2. Lista de los estados del servidor MySQL");
    System.out.println("3. Lista de variables de configuración del servidor MySQL");
    System.out.println("4. Gestión de usuarios");
    System.out.println("5. Gestión de las bases de datos en el servidor MySQL");
    System.out.println("6. Consultas de la base de Datos");

    System.out.println("0. Salir");
  }

  public static void pulsa_tecla() {
    System.out.println("Pulsa ENTER para continuar...");
    try {
      System.in.read(); // Espera a que el usuario presione una tecla
    } catch (Exception e) {
    }
  }
}
