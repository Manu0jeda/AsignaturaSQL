import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


class Consultas {
  String url = null; // URL de conexión
  String usuario = null; // usuario de MySQL
  String password = null; // contraseña de MySQL
  static int numResp = 0;

  Connection conexion = null;
  Statement sentencia = null;
  ResultSet resultado = null;


  Consultas(String url, String usuario, String password) {
    this.url = url;
    this.usuario = usuario;
    this.password = password;
    sentencia = conectar();
    if (sentencia == null)
      return;
    else
      realizarConsulta();
  }

  Statement conectar() {
    Statement sentencia = null;
    try {
      // 1.- Cargar el driver JDBC para MySQL que está en mysql-connector-j-9.1.0.jar
      Class.forName("com.mysql.cj.jdbc.Driver");

      // 2.- Establecer la conexión
      // Conecta al servidor MySQL. La URL no incluye el nombre de una base de datos específica,
      // ya que queremos listar todas las bases de datos.
      conexion = DriverManager.getConnection(url, usuario, password);

      // 3.- Crea un objeto Statement para ejecutar consultas SQL
      sentencia = conexion.createStatement();
      return sentencia;
    } catch (ClassNotFoundException e) {
      System.err.println("Error: No se pudo cargar el controlador JDBC: " + e.getMessage());
      return null;
    } catch (SQLException e) {
      System.err.println("Otro error JDBC: " + e.getMessage());
      return null;
    }
  }

  // Generacion de HTML
  String resultSetToHtmlTable(ResultSet rs) throws SQLException {
    StringBuilder htmlTable = new StringBuilder();
    ResultSetMetaData metaData = rs.getMetaData();
    int columnCount = metaData.getColumnCount();

    // Inicio de la tabla HTML
    htmlTable.append("<table border='1'>\n");

    // Encabezados de la tabla
    htmlTable.append("<tr>");
    for (int i = 1; i <= columnCount; i++) {
      htmlTable.append("<th>").append(metaData.getColumnName(i)).append("</th>");
    }
    htmlTable.append("</tr>\n");

    // Filas con datos
    while (rs.next()) {
      htmlTable.append("<tr>");
      for (int i = 1; i <= columnCount; i++) {
        htmlTable.append("<td>").append(rs.getObject(i) != null ? rs.getObject(i).toString() : "")
            .append("</td>");
      }
      htmlTable.append("</tr>\n");
    }

    // Cierre de la tabla
    htmlTable.append("</table>");

    return htmlTable.toString();
  }

  // Guardar fichero HTML, Cambiar el directorio donde quiera que se guarde
  void guardarHTMLEnFichero(String contenido) {
    String nombreFichero = "respuesta" + (numResp++) + ".html";
    nombreFichero = "/home/a04/Desarrollo/" + nombreFichero;

    try (FileWriter writer = new FileWriter(nombreFichero)) {
      writer.write(contenido);
      System.out.println("El HTML generado se ha guardado en " + nombreFichero);
    } catch (IOException e) {
      System.err.println("Error al guardar el string en el fichero: " + e.getMessage());
    }
  }

  void ejecutarQuery(String query) {
    List<String> cabeceras = new ArrayList<>();
    try {
      resultado = sentencia.executeQuery(query);
      ResultSetMetaData metaDatos = resultado.getMetaData();
      int numeroColumnas = metaDatos.getColumnCount();
      String nombreColumna = "";

      // Se obtiene sólo los nombres de las columnas
      for (int i = 1; i <= numeroColumnas; i++) {
        nombreColumna = metaDatos.getColumnName(i);
        cabeceras.add(nombreColumna);
      }
      ejecutarQuery(query, cabeceras);


    } catch (SQLException e) {
      System.err.println("Error de consulta a la Base de Datos: \n" + e.getMessage());
    }
  }

  void ejecutarQuery(String query, List<String> cabecera) {
    String html = "";
    try {
      System.out.println("\n Resultado: \n" + query);

      resultado = sentencia.executeQuery(query);
      html = resultSetToHtmlTable(resultado);
      System.out.println(html);
      guardarHTMLEnFichero(html);
    } catch (SQLException e) {
      System.err.println("Error de consulta a la Base de Datos: \n" + e.getMessage());
    }
  }

  void pedidosQueryPreparada() {
    String query = "SELECT * FROM pedidos WHERE Id_Cliente = ?";
    try {
      PreparedStatement sentenciaPreparada = conexion.prepareStatement(query);

      // Solicitar al usuario que ingrese un Id de cliente
      Scanner scanner = new Scanner(System.in);
      System.out.print("Id de cliente para obtener sus pedidos: ");
      // Leer el número ingresado por el usuario
      int clienteId = scanner.nextInt();

      // cargar el valor del parámetro
      sentenciaPreparada.setInt(1, clienteId);
      // ejecutar el query
      resultado = sentenciaPreparada.executeQuery();

      // recorrer ResultSet
      while (resultado.next()) {
        // Access data using column names or indexes
        int orderId = resultado.getInt("Id_Pedido");
        String orderDate = resultado.getString("FechaPedido");
        double orderCargo = resultado.getDouble("Cargo");

        // ... process other columns

        System.out.println("ID de pedido: " + orderId + ", Fecha del pedido: " + orderDate
            + ", Valor del pedido: " + orderCargo);
      }
      scanner.close(); // Cerramos el scanner
    } catch (SQLException e) {
      System.out.println("Error executing the query: " + e.getMessage());
    }

  }

  void realizarConsulta() {
    try {
      System.out.println("Elija una base de datos: \n");
      Scanner scanner2 = new Scanner(System.in);
      String nombreDB;
      nombreDB = scanner2.nextLine();
      sentencia.executeUpdate("USE " + nombreDB);
      String sql;
      System.out.println("Seleccione una consulta: \n");
      int opcion = 0;
      mostrarMenu2(); // Mostramos el menú
      do {
        try {
          opcion = Integer.parseInt(scanner2.nextLine());
        } catch (Exception e) {
          opcion = 0;
        }
        switch (opcion) {
          case 1:
            sql =
                "SELECT pedidos.Id_Empleado, SUM(detallespedidos.Cantidad * detallespedidos.PrecioUnidad * (1 - detallespedidos.Descuento)) AS Cuantia "
                    + "FROM pedidos "
                    + "JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido "
                    + "GROUP BY pedidos.Id_Pedido, pedidos.Id_Empleado "
                    + "ORDER BY pedidos.Id_Empleado;";
            ejecutarQuery(sql);
            break;
          case 2:
            sql = "SELECT IdProducto, SUM(Cantidad) AS Unidades_Vendidas " + "FROM detallespedidos "
                + "WHERE IdProducto = 1 " + "GROUP BY IdProducto;";
            ejecutarQuery(sql);
            break;
          case 3:
            sql = "SELECT IdProducto, SUM(Cantidad) AS Cantidades_Vendidas "
                + "FROM detallespedidos " + "GROUP BY IdProducto " + "ORDER BY IdProducto;";
            ejecutarQuery(sql);
            break;
          case 4:
            sql = "SELECT * " + "FROM productos " + "ORDER BY NombreProducto ASC;";
            ejecutarQuery(sql);
            break;
          case 5:
            sql = "SELECT Id_Cliente, NombreContacto, Pais, Ciudad, CodPostal " + "FROM clientes "
                + "WHERE Id_Cliente < 10 " + "ORDER BY NombreContacto ASC;";
            ejecutarQuery(sql);
            break;
          case 6:
            sql =
                "SELECT pedidos.Id_Cliente,clientes.NombreCompania, SUM(pedidos.Cargo) AS Valor_Total_Pedidos "
                    + "FROM pedidos " + "JOIN clientes ON clientes.Id_Cliente = pedidos.Id_Cliente "
                    + "GROUP BY clientes.Id_Cliente, clientes.NombreCompania "
                    + "ORDER BY Valor_Total_Pedidos DESC;";
            ejecutarQuery(sql);
            break;
          case 7:
            pedidosQueryPreparada();
            break;
          case 0:
            break;
          default:
            System.out.println("Opción no válida.");
            pulsa_tecla();

        }
      } while (opcion != 0); // Repetimos hasta que el usuario elija la opción 0


      scanner2.close(); // Cerramos el scanner

      // Cerrar la conexión y los recursos

      sentencia.close();
      conexion.close();
      resultado.close();
    } catch (SQLException e) {
      System.err.println("Error: " + e.getMessage());
    }
  }

  private static void mostrarMenu2() {
    System.out.println("\n--- Menú ---");
    System.out.println(
        "1. Cuantia de cada pedido junto con el id del empleado que la ha realizado, ordenado por Id_Empleado.");
    System.out
        .println("2. Obtener el total de las cantidades vendidas del producto con Id_Producto.");
    System.out.println("3. Obtener para cada Id_Producto, el total de cantidades vendidas.");
    System.out.println("4. Ordenar la tabla Productos por NombreProducto ascendente.");
    System.out.println("5. Obtener el Id_Cliente, nombre de contacto, país, ciudad y código postal de los "
            + "clientes cuyo Id_Cliente es menor de 10 ordenado por el nombre de contacto ascendente.");
    System.out
        .println("6. Presentar le id de cliente y compañía con  el valor tot6al de los pedidos "
            + "realizados por ese cliente.");
    System.out.println("7. Ejecutar secuencia preparada (Prepared Statement).");
    System.out.println("0. Salir");
  }

  public static void pulsa_tecla() {
    System.out.println("Pulsa ENTER para continuar...");
    try {
      System.in.read(); // Espera a que el usuario presione una tecla
    } catch (Exception e) {
    }
  }

}
