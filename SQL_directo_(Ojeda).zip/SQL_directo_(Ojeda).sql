USE ventas;

-- 1.- Diseñar una consulta que seleccione todos los registros de la tabla Empleados.
SELECT * FROM empleados;

-- 2.- Diseñar una consulta que devuelva el nombre de la compañía, nombre del contacto y teléfono de todos los proveedores.
SELECT NombreCompania, NombreContacto, Telefono FROM proveedores;

-- 3.- Diseñar una consulta que nos devuelva el nombre del producto, la cantidad de ese producto por cada unidad, el precio por unidad 
-- y las unidades en existencia de nuestros productos. Los titulos de esas columnas deberán ser, respectivamente, Nombre, UnidadesPorCaja,
-- Precio y Stock.
SELECT
	NombreProducto AS Nombre,
	CantidadPorUnidad AS UnidadesPorCaja,
	PrecioUnidad AS Precio,
	UnidadesEnExistencia AS Stock
FROM productos;

-- 4.- Diseñar una consulta que me diga los países en los cuales tengo clientes.
SELECT DISTINCT Pais
FROM clientes;

-- 5.- Qué ocurre si en la sentencia anterior, quiero que también me devuelva el Nombre del Contacto.
SELECT DISTINCT Pais, NombreContacto
FROM clientes;
-- Se repiten los paises pero la combinacion Pais-Nombre contacto es unica.

-- 6.- Diseñar una consulta que me devuelva el nombre y la ciudad de mis clientes que son españoles.
SELECT NombreContacto, Ciudad
FROM clientes
WHERE Pais = 'Espana';

-- 7.- Diseñar una consulta que me devuelva el nombre de la compañía, el nombre de contacto, la ciudad, el teléfono y el fax de aquellos
-- proveedores que son de Estados Unidos y su ciudad New Orleans.
SELECT NombreCompania, NombreContacto, Ciudad, Telefono, Fax
FROM proveedores
WHERE Pais = 'Estados Unidos' AND Ciudad = 'New Orleans';

-- 8.- Diseñar una consulta que me devuelva el nombre del contacto, la compañía, el país, la ciudad y el teléfono de mis clientes franceses o ingleses.
SELECT NombreContacto, NombreCompania, Pais, Ciudad, Telefono
FROM clientes
WHERE Pais = 'Francia' OR Pais = 'Reino Unido'; -- Podria ser tambien con WHERE IN ('Francia','Reino Unido');

-- 9.- Diseñar una consulta que me diga que productos no han sido enviados (nos da igual el motivo) a Estados Unidos o Alemania,
-- devolviéndome el destinatario, su dirección y su país.
SELECT 
	productos.NombreProducto AS ProductoNoEnviado,
	Destinatario,
	DireccionDestinatario,
	PaisDestinatario 
FROM pedidos
	JOIN detallespedidos ON detallespedidos.Id_Pedido = pedidos.Id_Pedido
	JOIN productos ON productos.Id_Producto = detallespedidos.IdProducto
WHERE FechaEnvio = '' AND !(PaisDestinatario  = 'Estados Unidos' OR PaisDestinatario = 'Alemania');

-- 10.- Diseñar una consulta que me diga el nombre, la compañía, la dirección, la ciudad y el pais de mis clientes que son de España y estén ubicadas
-- en el código postal 28023 y las que son de México y su código sea el 05033.
SELECT NombreContacto, NombreCompania, Direccion, Ciudad, Pais
FROM clientes
WHERE (Pais ='Espana' AND CodPostal = '28023') OR (Pais ='Mexico' AND CodPostal = '5033'); -- Se quita el cero al CodigoPostal para que salgan los de
-- Mexico, ya que es un VARCHAR pero en el CSV al importarlo en los datos aparece como 5033.

-- 11.- Diseñar una consulta que me devuelva el destinatario, su dirección, su ciudad y su país de aquellos pedidos que no sean para Estados Unidos, 
-- Reino Unido ni Francia.
SELECT Destinatario, DireccionDestinatario, CiudadDestinatario, PaisDestinatario
FROM pedidos
WHERE PaisDestinatario NOT IN ('Estados Unidos', 'Reino Unido', 'Francia');

-- 12.- Diseñar una consulta que me devuelva el nombre del producto y su Id de aquellos productos que tengo en existencia una cantidad entre 53 y 120 
-- (ambas inclusive).
SELECT NombreProducto, Id_Producto
FROM productos
WHERE UnidadesEnExistencia BETWEEN 53 AND 120;

-- 13.- Diseñar una consulta que me devuelva el Id del producto, nombre del producto, el precio por unidad, unidades en existencia y unidades 
-- en pedido de aquellos pedidos cuyas unidades en existencia esté comprendidas entre 0 y 100, que tenga solicitado unidades en pedido y cuyo
-- precio por unidad sea mayor que 15 €.
SELECT Id_Producto, NombreProducto, PrecioUnidad, UnidadesEnExistencia, UnidadesEnPedido
FROM productos
WHERE (UnidadesEnExistencia BETWEEN 0 AND 100) AND (UnidadesEnPedido > 0) AND (PrecioUnidad > 15);

-- 14.- Diseñar una consulta que me devuelva el Id del proveedor, el total de unidades en pedido (cuyo titulo de columna será Unidades_Pedidas) 
-- de mis productos cuyas unidades en pedido sean mayor que 0 y me las presente agrupadas por el Id_Proveedor.
SELECT Id_Proveedor, SUM(UnidadesEnPedido) AS Unidades_Pedidas
FROM productos
WHERE UnidadesEnPedido > 0
GROUP BY Id_Proveedor;

-- 15.- Diseñar una consulta que me devuelva la cuantia de cada pedido junto con el id del empleado que la ha realizado, ordenado por Id_Empleado.
SELECT pedidos.Id_Empleado, SUM(detallespedidos.Cantidad * detallespedidos.PrecioUnidad * (1 - detallespedidos.Descuento)) AS Cuantia
FROM pedidos
JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido
GROUP BY pedidos.Id_Pedido, pedidos.Id_Empleado
ORDER BY pedidos.Id_Empleado;

-- 15.b Si se refiere a la cuantía generada por cada empleado seria:
-- SELECT SUM(detallespedidos.Cantidad * detallespedidos.PrecioUnidad * (1 - detallespedidos.Descuento)), Pedidos.Id_Empleado FROM DetallesPedidos
-- INNER JOIN Pedidos ON DetallesPedidos.Id_Pedido = Pedidos.Id_pedido
-- GROUP BY Pedidos.Id_Empleado
-- ORDER BY Pedidos.Id_empleado;

-- 16.- Modiﬁcar la consulta anterior para que me devuelva solo lo vendido por el empleado cuyo id es 8.
SELECT pedidos.Id_Empleado,SUM(detallespedidos.Cantidad * detallespedidos.PrecioUnidad * (1 - detallespedidos.Descuento)) AS TotalVendido
FROM pedidos
JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido
WHERE pedidos.Id_Empleado = 8
GROUP BY pedidos.Id_Pedido, pedidos.Id_Empleado

-- 17.- Modiﬁcar la consulta anterior para que me devuelva el total de ventas de ese empleado.
SELECT COUNT(DISTINCT detallespedidos.Id_Pedido) AS TotalDeVentas, Id_Empleado
FROM pedidos
JOIN detallespedidos ON detallespedidos.Id_Pedido = pedidos.Id_pedido
WHERE Id_empleado = 8;

-- 18.- Modiﬁcar la consulta anterior para que me devuelva el total de ventas (campo cargo de la tabla pedidos) de cada uno de los empleados.
-- Con la modificacion de las tablas ya no usamos el campo cargo. 
SELECT Id_Empleado, COUNT(DISTINCT detallespedidos.Id_Pedido) AS TotalDeVentas
FROM pedidos
JOIN detallespedidos ON detallespedidos.Id_Pedido = pedidos.Id_pedido
GROUP BY Id_Empleado 
ORDER BY Id_Empleado;

-- 19.- Queremos de todos los pedidos (DetallesPedidos) todas las ventas del producto IdProducto. Los campos a visualizar serán Id_Producto y cantidad.
SELECT IdProducto, Cantidad
FROM detallespedidos
WHERE IdProducto = 1;

-- 20.- El siguiente paso es, obtener el total de las cantidades vendidas del producto con Id_Producto, la columna del total la llamaremos Unidades_Vendidas.
SELECT IdProducto, SUM(Cantidad) AS Unidades_Vendidas
FROM detallespedidos
WHERE IdProducto = 1
GROUP BY IdProducto;

-- 21.- Obtener para cada Id_Producto, el total de cantidades vendidas (tabla detallespedidos).
SELECT IdProducto, SUM(Cantidad) AS Cantidades_Vendidas
FROM detallespedidos
GROUP BY IdProducto
ORDER BY IdProducto;

-- 22.- Obtener el total de las cantidades vendidas (la columna del total la llamaremos Unidades_Vendidas)
-- agrupadas por el IdProducto, pero solo queremos aquellos gupos con IdProducto superior a 70.
SELECT IdProducto, SUM(Cantidad) AS Unidades_Vendidas
FROM detallespedidos
WHERE IdProducto > 70
GROUP BY IdProducto 
ORDER BY IdProducto; 

-- 23.- Ordenar la tabla Productos por NombreProducto ascendente.
SELECT *
FROM productos
ORDER BY NombreProducto ASC;

-- 24.- Ordenar la tabla Clientes de manera que se ordene ascendentemente por el país y descendientemente 
-- por el campo Ciudad. Los campos a visualizar, se deben presentar con el siguiente orden:
-- País – Ciudad – NombreCompania , este último se debe renombrar su titulo de columna a Compañía.
SELECT Pais, Ciudad, NombreCompania AS Compañía
FROM clientes
ORDER BY Pais ASC, Ciudad DESC;

-- 25.- Obtener el Id_Cliente, nombre de contacto, país, ciudad y código postal de los clientes cuyo Id_Cliente 
-- es menor de 10 ordenado por el nombre de contacto ascendente.
SELECT Id_Cliente, NombreContacto, Pais, Ciudad, CodPostal
FROM clientes
WHERE Id_Cliente < 10
ORDER BY NombreContacto ASC;

-- 26.- Seleccionar el precio por unidad, nombre del producto, unidades en existencia y si el producto está suspendido de los productos que 
-- se encuentran suspendidos (de la tabla productos) y que existen unidades en existencia. Queremos los datos ordenador por precio unidad y 
-- unidades en existencia descendentemente.
SELECT PrecioUnidad, NombreProducto, UnidadesEnExistencia, Suspendido
FROM productos
WHERE Suspendido = 'Verdadero' AND UnidadesEnExistencia > 0
ORDER BY PrecioUnidad DESC, UnidadesEnExistencia DESC;

-- 31.- Diseñar una consulta que me devuelva el Id del pedido, el valor total del pedido redondeado a dos decimales.
SELECT Id_Pedido, ROUND(SUM(PrecioUnidad * Cantidad * (1 - Descuento)),2) AS Total_Pedido
FROM detallespedidos
GROUP BY Id_Pedido
ORDER BY Id_Pedido;

-- 32.- Cargar la columna cargo de la tabla pedidos con el valor resultante de ROUND(SUM(PrecioUnidad * Cantidad * (1 - Descuento)),2) AS Total
--  de la tabla detallespedidos.
UPDATE pedidos
SET Cargo = (SELECT ROUND(SUM(PrecioUnidad * Cantidad * (1 - Descuento)),2)
FROM detallespedidos
WHERE detallespedidos.Id_Pedido = pedidos.Id_Pedido);


-- 33.- Mediante SELECT anidadas, obtener el nombre de producto, id de categoría y precio unidad de los productos cuya categoría es “Lacteos”.
SELECT NombreProducto, Id_Categoria, PrecioUnidad
FROM productos
WHERE Id_Categoria IN (
	SELECT Id_Categoria
	FROM categorias
	WHERE NombreCategoria = 'Lacteos'
);

-- 34.- Crear el promedio de los precios del conjunto de productos seleccionados en el ejercicio anterior.
SELECT AVG(PrecioUnidad) AS Promedio_Precios_Lacteos
FROM productos
WHERE id_categoria IN (
    SELECT id_categoria
    FROM categorias
    WHERE NombreCategoria = 'Lacteos'
);

-- 35.- Mediante SELECT anidadas, encuentra los nombres de los productos con su categoría y precioUnidad que tienen un precio más alto que el precio
-- promedio de los productos de la categoría 'Lácteos'.
SELECT NombreProducto, Id_categoria, PrecioUnidad
FROM productos
WHERE PrecioUnidad > (
    SELECT AVG(PrecioUnidad)
    FROM productos
    WHERE id_categoria IN (
        SELECT id_categoria
        FROM categorias
        WHERE NombreCategoria = 'Lácteos'
    )
);

-- 36.- Presentar le id de cliente y compañía con  el valor total de los pedidos realizados por ese cliente.
SELECT pedidos.Id_Cliente,clientes.NombreCompania, SUM(pedidos.Cargo) AS Valor_Total_Pedidos
FROM pedidos 
JOIN clientes ON clientes.Id_Cliente = pedidos.Id_Cliente
GROUP BY clientes.Id_Cliente, clientes.NombreCompania
ORDER BY Valor_Total_Pedidos DESC;

-- 37.- Mediante SELECT anidadas, encontrar los nombres de los clientes que hayan realizado pedidos con un valor total mayor que el valor promedio de 
-- todos los pedidos.
SELECT clientes.NombreContacto
FROM clientes 
WHERE EXISTS (
    SELECT 1
    FROM pedidos
    WHERE pedidos.Id_Cliente = clientes.Id_Cliente AND pedidos.cargo > (
        SELECT AVG(cargo)
        FROM pedidos
    )
);

-- 38.- Añadir estos dos empleados a la tabla de empleados. (Se insertan los datos de la tabla dada en el enunciado).
INSERT INTO empleados (Id_Empleado, Apellidos, Nombre, Cargo, Tratamiento, FechaNacimiento, FechaContratacion, Direccion, Ciudad, Region, CodPostal,
Pais, TelDomicilio, Extension, Notas, Jefe)
VALUES 
(10, 'Calagan', 'Daniel', 'Representante de ventas', 'Sr.', '1958-01-09', '1994-03-05', 'Princesa 12', 'Madrid', 'Madrid', '28012',
'Espanya', '914456288', 2344, 'Grado en Económicas', '8'),
(11, 'García', 'Marta', 'Representante de ventas', 'Srta.', '1969-07-02', '1994-11-15', 'Princesa 13', 'Madrid', 'Madrid', '28012',
'Espanya', '914456655', 452, 'Grado en Marketing', '8');

-- 39.- Utilizando SELECT anidadas, presentar los nombres de los empleados que no han realizado ningún pedido.
SELECT Nombre, Apellidos
FROM empleados
WHERE Id_Empleado NOT IN (
    SELECT DISTINCT pedidos.Id_Empleado
    FROM pedidos
);

-- 40.- Crear dos productos en la tabla de productos.(Se insertan los datos de la tabla dada en el enunciado).
INSERT INTO productos (Id_Producto, NombreProducto, Id_Proveedor, Id_Categoria, CantidadPorUnidad, PrecioUnidad, UnidadesEnExistencia, Suspendido)
VALUES 
(78, 'Garbanzos', 12, 2, '12 cajas', 10, 120, FALSE),
(79, 'Acelgas', 12, 2, '10 bolsas', 15, 100, FALSE);
-- Se añade suspendido para que no se produzca error ya que no tiene valor por defecto.

-- 41.- Utilizando SELECT encuentra los nombres de los productos que no se han empleado en ningún pedido.
SELECT NombreProducto
FROM productos
WHERE productos.Id_Producto NOT IN (
	SELECT DISTINCT detallespedidos.IdProducto
	FROM detallespedidos
	);

-- 42.- Utilizando JOIN encuentra los nombres de los productos que no se han empleado en ningún pedido.
SELECT NombreProducto
FROM productos
LEFT JOIN detallespedidos ON productos.Id_Producto = detallespedidos.IdProducto
WHERE detallespedidos.IdProducto IS NULL;

-- 43.- Mediante subconsulta SELECT presentar los nombres de los clientes que han realizado pedidos enviados al mismo país en el que se encuentran.
SELECT DISTINCT NombreContacto
FROM clientes
WHERE clientes.Id_Cliente IN (
	SELECT pedidos.Id_Cliente
	FROM pedidos
	WHERE pedidos.PaisDestinatario = clientes.Pais
	)
ORDER BY NombreContacto  ASC;

-- 44.- Mediante JOIN presentar los nombres de los clientes que han realizado pedidos enviados al mismo país en el que se encuentran.
SELECT DISTINCT NombreContacto
FROM clientes
JOIN pedidos ON clientes.Id_Cliente = pedidos.Id_Cliente
WHERE clientes.Pais = pedidos.PaisDestinatario
ORDER BY NombreContacto  ASC;

-- 45.-LEFT JOIN Muestra todos productos (tabla izquierda) y sus categorías si existen. Si no hay coincidencia (ejemplo: Acelga), se devuelve NULL 
-- en la columna de categorías. Compara este ejemplo con LEFT JOIN usando JOIN

-- LEFT JOIN:
SELECT NombreProducto, categorias.NombreCategoria
FROM productos
LEFT JOIN categorias ON productos.Id_Categoria = categorias.Id_Categoria
ORDER BY productos.NombreProducto;
-- JOIN:
SELECT NombreProducto, categorias.NombreCategoria
FROM productos
JOIN categorias ON productos.Id_Categoria = categorias.Id_Categoria
ORDER BY productos.NombreProducto;

-- En este caso todos los productos tienen categoría. Pero en caso de no tener categoría, el LEFT JOIN mostraría todos los productos y el que no tiene 
-- categoría lo mostraría como NULL. Sin embargo el INNER JOIN, solo mostraría los productos con categoría.

-- 46.- RIGHT JOIN. Muestra todos las categorías (tabla derecha) y los productos asociados si existen. Si no hay coincidencia (ejemplo: vinos), se 
-- devuelve NULL en la columna del producto.
SELECT categorias.NombreCategoria, productos.NombreProducto
FROM productos
RIGHT JOIN categorias ON productos.Id_Categoria = categorias.Id_Categoria
ORDER BY categorias.NombreCategoria;

-- Este caso es similar al anterior. Con RIGHT JOIN se muestran todos los productos de una categoría y si alguna categoría no tiene ningún producto
-- asociado, devuelve NULL. con INNER JOIN se muestran solo las categorías con productos asociados.

-- 47.- Dada una tabla de categorias y otra de productos, escribe una consulta SQL para mostrar el nombre de cada categoría, junto con el nombre y el 
-- precio unitario de los productos dentro de esa categoría.
SELECT categorias.NombreCategoria, productos.NombreProducto, productos.PrecioUnidad
FROM categorias
LEFT JOIN productos ON categorias.Id_Categoria = productos.Id_Categoria -- En caso de querer solo las categorías con productos asociados sería INNER JOIN.
ORDER BY categorias.NombreCategoria, productos.NombreProducto;

-- 48.- Crear una vista de tres tablas relacionadas cuyo resultado es: (Tabla con Compañia cliente, Numero de pedido, Nombre empleado y Apelido empleado).
CREATE VIEW pedidos_clientes_empleados AS
SELECT clientes.NombreCompania AS Compañia_Cliente, pedidos.Id_Pedido AS Numero_Pedido, empleados. Nombre AS Nombre_Empleado, empleados.Apellidos AS
	Apellido_Empleado
FROM clientes
JOIN pedidos ON clientes.Id_Cliente = pedidos.Id_Cliente
JOIN empleados ON pedidos.Id_empleado = empleados.Id_Empleado;

-- 49.- Realizar una consulta que combina datos de 5 tablas (clientes, pedidos, detallespedidos, productos, y empleados) para obtener información 
-- específica de compañías clientes, empleados que hicieron el pedido y los productos, filtrada porque los clientes deben ser de las  ciudades Londres y 
-- Madrid. Salida ordenada por ciudad
-- Relación entre tablas
	-- clientes → pedidos → detallespedidos → productos → Empleados        
     --  • clientes está vinculada a pedidos por Id_Cliente.
     --  • pedidos está vinculada a detallespedidos por Id_Pedido.
     --  • detallespedidos está vinculada a productos por IdProducto.
     --  • pedidos está vinculada a empleados por Id_Empleado.
    SELECT clientes.NombreCompania, clientes.Ciudad, empleados.Nombre AS Nombre_Empleado, empleados.Apellidos AS Apellido_Empleado, productos.NombreProducto,
    detallespedidos.Cantidad, detallespedidos.PrecioUnidad
    FROM clientes
    JOIN pedidos ON clientes.Id_Cliente = pedidos.Id_Cliente
    JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido
    JOIN productos ON detallespedidos.IdProducto = productos.Id_Producto
    JOIN empleados ON pedidos.Id_Empleado = empleados.Id_Empleado
    WHERE clientes.Ciudad IN ('Londres', 'Madrid')
    ORDER BY clientes.Ciudad, clientes.NombreCompania, empleados.Apellidos,productos.NombreProducto;

-- 102.1.- Sentencia SQL para ver el tipo de claves de cada campo de una tabla 
	-- 102.1.1.- Con SHOW
	SHOW INDEXES FROM clientes;
	
	-- 102.1.2. Con DESCRIBE:
	DESCRIBE clientes;

-- 102.2.- Crear una PRIMARY KEY. En clientes, con una sentencia SQL cambiar el Id_Cliente al tipo de clave PRIMARY KEY:
	-- 102.2.1.- Comprobar si hay valores NULL
	SELECT *
	FROM clientes
	WHERE Id_Cliente IS NULL; 

	-- 102.2.2.- Comprobar si hay valores repetidos
	SELECT Id_Cliente, COUNT(*)
	FROM clientes
	GROUP BY Id_Cliente
	HAVING COUNT(*) > 1;
	
	-- 102.2.3.- Cambiar  Id_Cliente a PRIMARY KEY, añadir la forma autoincrementado al valor del campo
	ALTER TABLE clientes
	MODIFY COLUMN Id_Cliente INT AUTO_INCREMENT PRIMARY KEY;
	
-- 102.3.- Crear una UNIQUE KEY. Cambiar el campo Fax por CorreoElectronico con una longitud de 60 caracteres. 
-- Generar email automático con nombreContacto @ nombreCompania .com
	-- 102.3.1.- Cambiar el nombre del campo Fax por CorreoElectronico, tipo texto y con una longitud de 60 caracteres.
	ALTER TABLE clientes
	CHANGE COLUMN Fax CorreoElectronico VARCHAR(60);

	-- 102.3.2.- Generar correo electrónico a partir de NombreContacto y NombreCompania:
	SELECT
        CONCAT(REPLACE(NombreContacto, ' ', '_') , '@', 
			   REPLACE(NombreCompania, ' ', '_'), '.com') AS 'CorreoElectrónico'
	FROM clientes
	
	-- 102.3.3.- Sustituir los valores del campo CorreoElectronico por los valores generados en el apartado anterior
	UPDATE clientes
	SET CorreoElectronico = 
        CONCAT(REPLACE(NombreContacto, ' ', '_') , '@', 
		  	   REPLACE(NombreCompania, ' ', '_'), '.com')
		  	   
	-- 102.3.4.- Comprobar que no hay valores nulos ni repetidos, utilizando 2.2.1 y 2.2.2
		-- Comprobacion nulos
		SELECT *
		FROM clientes
		WHERE CorreoElectronico IS NULL; 
		-- Comprobacion repetidos
		SELECT CorreoElectronico, COUNT(*)
		FROM clientes
		GROUP BY Id_Cliente, CorreoElectronico 
		HAVING COUNT(*) > 1;
	
	-- 102.3.5.- El campo CorreoElectronico debe ser de UNIQUE KEY
	ALTER TABLE clientes
	ADD CONSTRAINT correoUnico UNIQUE (CorreoElectronico);
	
-- 102.4.- Crear una KEY en el campo FechaDePedido de la tabla pedidos
ALTER TABLE pedidos
ADD INDEX IDX_FechaPedido (FechaPedido);
	
-- 151.- Añadir columna salario a empleados con un valor aleatorio entre 20000 y 40000
ALTER TABLE empleados
ADD Salario DECIMAL(10, 2);
UPDATE empleados
SET Salario = FLOOR(RAND() * (40000 - 20000 + 1) + 20000);

-- 152.- Crear un script SQL en el que se define una variable, se le asigna un valor y luego esa variable se utiliza en una sentencia `INSERT`. 
SET @nom = 'verduras';
SET @id = 234;
SET @des = 'Todo tipo de verduras';
INSERT INTO categorias (Id_categoria,nombreCategoria,descripcion) VALUES (@id,@nom, @des);

-- 153.- Encontrar los productos que existen en la tabla Productos pero no en la tabla detallespedidos (no se han vendido nunca).
SELECT id_producto FROM productos
EXCEPT
SELECT idproducto FROM detallespedidos

	-- 154.1.- En una vista, convertir el formato de cadena 'DD-MM-YYYY' de la columna fechaPedido a un tipo de fecha MySQL utilizando la función
	-- STR_TO_DATE() en una SELECT
	SELECT STR_TO_DATE(FechaPedido, '%d/%m/%Y') AS FechaPedidoConvertida
	FROM pedidos;
	
	-- 154.2.- Actualizar la tabla y convertir permanentemente la columna FechaPedido a tipo DATE,  siguiendo estos pasos:
		-- Agregar una nueva columna llamada FechaPedidoConvertida de tipo DATE.
		ALTER TABLE pedidos
		ADD COLUMN FechaPedidoConvertida DATE AFTER FechaPedido;
	
		-- Actualizar la nueva columna con las fechas convertidas utilizando STR_TO_DATE(). 
		UPDATE pedidos
		SET FechaPedidoConvertida = STR_TO_DATE(FechaPedido, '%d/%m/%Y');
		
		-- Eliminar la columna original FechaPedido que contenía las fechas en formato de texto. 
		ALTER TABLE pedidos
		DROP COLUMN FechaPedido;
		
		-- Renombrar la nueva columna FechaPedidoConvertida a FechaPedido.
		ALTER TABLE pedidos
		CHANGE COLUMN FechaPedidoConvertida FechaPedido DATE;
		
	-- 155.1.- Obtener información sobre empleados, con su identificación, nombre, salario, creando un ranking basado en el salario, 
	-- mostrando los empleados con mayor rango de salario primero.
	SELECT id_empleado, nombre, Salario,
    RANK() OVER (ORDER BY salario DESC) AS rango_salario
	FROM empleados;

	-- 155.2.- Obtener información sobre productos, con su identificación, nombre, cantidad en existencia, crerando un ranking basado en
	-- la cantidad en existencia, mostrando los productos con mayor existencia primero.
	SELECT productos.Id_Producto, productos.NombreProducto, productos.UnidadesEnExistencia,
    RANK() OVER (ORDER BY productos.UnidadesEnExistencia DESC) AS rango_existencias
	FROM productos;
	
	-- 155.3.- Obtener información sobre productos, con su identificación, nombre, valor (cantidad * precio), creando un ranking basado en valor
	-- (cantidad * precio), mostrando los productos con mayor valor primero.
	SELECT productos.Id_Producto, productos.NombreProducto,
	ROUND(productos.CantidadPorUnidad* productos.PrecioUnidad,1) AS valor,
    RANK() OVER (ORDER BY productos.CantidadPorUnidad* productos.PrecioUnidad DESC) AS 'Rango de valores'
	FROM productos;
	
	-- 155.4.- Cálculo de la móvil con la tabla "Pedidos"
	SELECT FechaPedido, Cargo,
    ROUND(AVG(Cargo) OVER (ORDER BY FechaPedido ASC ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),2) AS promedio_movil_3_dias
	FROM pedidos;
	
	-- 155.5. Calcular medias móviles ponderadas de Cargo de la tabla Pedidos, utilizando como peso la Cantidad de productos vendidos en cada pedido.
	-- Inicialmente ensayamos obtener la cantidad de productos por pedido, uniendo las tablas Pedidos y DetallesPedidos y luego agrupar por Id_Pedido
	--  y FechaPedido.
	SELECT pedidos.Id_Pedido, pedidos.FechaPedido, SUM(detallespedidos.Cantidad) AS CantidadTotal, pedidos.Cargo 
	FROM pedidos 
	JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido 
	GROUP BY pedidos.Id_Pedido, pedidos.FechaPedido, pedidos.Cargo;
	-- Ahora componemos la sentencia SQL completa:
	WITH PedidosConCantidad AS (
    SELECT pedidos.Id_Pedido, pedidos.FechaPedido, SUM(detallespedidos.Cantidad) AS CantidadTotal, pedidos.Cargo
    FROM pedidos
    JOIN detallespedidos ON pedidos.Id_Pedido = detallespedidos.Id_Pedido
    GROUP BY pedidos.Id_Pedido, pedidos.FechaPedido, pedidos.Cargo
	)
	SELECT FechaPedido, Cargo,
    COALESCE(SUM(Cargo * CantidadTotal) OVER (ORDER BY FechaPedido ASC ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
        / SUM(CantidadTotal) OVER (ORDER BY FechaPedido ASC ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 0) AS media_movil_ponderada
	FROM PedidosConCantidad;
	
	-- 155.6.- Utilizar una función de ventana para calcular medias móviles ponderada con factor de ponderación ALFA de la tabla de pedidos
	SELECT FechaPedido, Cargo, ROUND((Cargo * (2 / (3 + 1))) + (LAG(Cargo, 1, 0) OVER (ORDER BY FechaPedido  ASC) * (1 - (2 / (3 + 1)))),2) AS EMA_3_dias
	FROM pedidos;
	
